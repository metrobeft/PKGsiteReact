import React from 'react';
import Header from '../Header';

const Layout = ({ children, onLogout, user }) => {
    return (
        <div>
            {/* Header com informações do usuário */}
            <Header onLogout={onLogout} user={user} />
            
            {/* Conteúdo Principal */}
            <main style={{ marginTop: '60px', padding: '20px' }}>
                {children}
            </main>
        </div>
    );
};

export default Layout;
