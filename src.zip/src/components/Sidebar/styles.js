import styled from 'styled-components';

export const Container = styled.div`
    background-color: #2c3e50;
    position: fixed;
    height: 100%;
    width: 250px;
    top: 0;
    left: 0;
    box-shadow: 2px 0 5px rgba(0, 0, 0, 0.5);
    display: flex;
    flex-direction: column;
    z-index: 1000;
    overflow-y: auto; /* Garante que o conteúdo não extrapole a altura */
`;

export const Content = styled.div`
    margin-top: 20px; /* Espaço abaixo do botão de fechar */
    display: flex;
    flex-direction: column;
`;
