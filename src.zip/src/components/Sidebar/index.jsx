import React from 'react';
import { FaTimes, FaHome, FaUserAlt, FaProjectDiagram, FaLanguage, FaCog } from 'react-icons/fa';
import { Container, Content } from './styles';
import SidebarItem from '../SidebarItem';

const Sidebar = ({ active, setActive }) => {
    const closeSidebar = () => setActive(false);

    return (
        <Container>
            <FaTimes
                onClick={closeSidebar}
                style={{
                    color: '#ecf0f1',
                    fontSize: '24px',
                    cursor: 'pointer',
                    margin: '20px',
                }}
            />
            <Content>
                <SidebarItem Icon={FaHome} Text="    Dashboard" link="/dashboard" />
                <SidebarItem Icon={FaUserAlt} Text="    Configurações de Conta" link="/account-settings" />
                <SidebarItem Icon={FaProjectDiagram} Text="    Projetos" link="/projects-panel" />
                <SidebarItem Icon={FaLanguage} Text="    Tradução" link="/translation-panel" />
                <SidebarItem Icon={FaCog} Text="     Painel ADM" link="/admin-panel" />
            </Content>
        </Container>
    );
};

export default Sidebar;
