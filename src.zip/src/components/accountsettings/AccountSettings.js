import React, { useState } from 'react';
import Layout from '../layout/Layout';
import './AccountSettings.css';

const AccountSettings = ({ onLogout, user }) => {
    const [newPassword, setNewPassword] = useState('');
    const [isEditing, setIsEditing] = useState(false);
    const [editedUser, setEditedUser] = useState({ ...user });
    const [isLoading, setIsLoading] = useState(false);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setEditedUser({ ...editedUser, [name]: value });
    };

    const handleUpdatePassword = async (e) => {
        e.preventDefault();
        setIsLoading(true);

        try {
            const response = await fetch('/api/update-password', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ userId: user.id, newPassword }),
            });

            if (response.ok) {
                alert('Senha atualizada com sucesso!');
                setNewPassword('');
            } else {
                alert('Erro ao atualizar senha.');
            }
        } catch (error) {
            console.error('Erro ao enviar a requisição:', error);
            alert('Erro ao atualizar a senha. Tente novamente mais tarde.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleDeleteAccount = async () => {
        if (window.confirm('Tem certeza que deseja excluir sua conta? Esta ação não pode ser desfeita.')) {
            setIsLoading(true);

            try {
                const response = await fetch('/api/delete-account', {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ userId: user.id }),
                });

                if (response.ok) {
                    alert('Conta deletada com sucesso!');
                    onLogout();
                } else {
                    alert('Erro ao deletar a conta.');
                }
            } catch (error) {
                console.error('Erro ao enviar a requisição:', error);
                alert('Erro ao deletar a conta. Tente novamente mais tarde.');
            } finally {
                setIsLoading(false);
            }
        }
    };

    const handleSaveProfile = async () => {
        setIsLoading(true);

        try {
            const response = await fetch('/api/update-profile', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ userId: user.id, updatedInfo: editedUser }),
            });

            if (response.ok) {
                alert('Informações atualizadas com sucesso!');
                setIsEditing(false);
            } else {
                alert('Erro ao salvar informações.');
            }
        } catch (error) {
            console.error('Erro ao enviar a requisição:', error);
            alert('Erro ao salvar informações. Tente novamente mais tarde.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Layout onLogout={onLogout} user={user}>
            <div className="dashboard-box">
                {/* Informações do Perfil */}
                <div className="dashboard-section">
                    <div className="profile-header">
                        <h2>Informações do Perfil</h2>
                        <div>
                            <button onClick={() => setIsEditing(!isEditing)} className="edit-button">
                                {isEditing ? 'Cancelar' : 'Editar'}
                            </button>
                            {isEditing && (
                                <button onClick={handleSaveProfile} className="save-button" disabled={isLoading}>
                                    {isLoading ? 'Salvando...' : 'Salvar'}
                                </button>
                            )}
                        </div>
                    </div>

                    <ul className="dashboard-list">
                        <li>Usuário: {user.username}</li>
                        <li>Senha: ********</li>
                        <li>
                            Email:
                            {isEditing ? (
                                <input
                                    type="email"
                                    name="email"
                                    value={editedUser.email}
                                    onChange={handleChange}
                                />
                            ) : (
                                <span>{user.email}</span>
                            )}
                        </li>
                        <li>
                            Dados de Contato:
                            {isEditing ? (
                                <input
                                    type="text"
                                    name="contactInfo"
                                    value={editedUser.contactInfo}
                                    onChange={handleChange}
                                />
                            ) : (
                                <span>{user.contactInfo}</span>
                            )}
                        </li>
                        <li>
                            Dados Bancários:
                            {isEditing ? (
                                <input
                                    type="text"
                                    name="bankInfo"
                                    value={editedUser.bankInfo}
                                    onChange={handleChange}
                                />
                            ) : (
                                <span>{user.bankInfo}</span>
                            )}
                        </li>
                    </ul>
                </div>

                {/* Atualizar Senha */}
                <div className="dashboard-section">
                    <h2>Atualizar Senha</h2>
                    <form className="account-form" onSubmit={handleUpdatePassword}>
                        <input
                            type="password"
                            placeholder="Nova Senha"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            required
                        />
                        <button type="submit" disabled={isLoading}>
                            {isLoading ? 'Atualizando...' : 'Atualizar'}
                        </button>
                    </form>
                </div>

                {/* Deletar Conta */}
                <div className="dashboard-section">
                    <h2>Deletar Conta</h2>
                    <p>
                        Atenção! Esta ação não pode ser desfeita. Certifique-se de que deseja excluir sua conta permanentemente.
                    </p>
                    <button className="delete-button" onClick={handleDeleteAccount} disabled={isLoading}>
                        {isLoading ? 'Deletando...' : 'Deletar Conta'}
                    </button>
                </div>
            </div>
        </Layout>
    );
};

export default AccountSettings;
