import React from 'react';

class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false };
    }

    static getDerivedStateFromError(error) {
        // Atualiza o estado para renderizar a interface de fallback
        return { hasError: true };
    }

    componentDidCatch(error, errorInfo) {
        // Loga os detalhes do erro para depuração
        console.error('[ErrorBoundary] Um erro foi capturado:', error, errorInfo);
    }

    render() {
        if (this.state.hasError) {
            return (
                <div style={{ textAlign: 'center', marginTop: '50px', color: '#fff' }}>
                    <h1>Algo deu errado.</h1>
                    <p>Por favor, tente novamente mais tarde.</p>
                </div>
            );
        }

        return this.props.children; 
    }
}

export default ErrorBoundary;
