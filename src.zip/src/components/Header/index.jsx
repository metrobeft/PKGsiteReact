import React, { useState } from 'react';
import { Container, LogoutButton } from './styles';
import { FaBars } from 'react-icons/fa';
import Sidebar from '../Sidebar';

const Header = ({ onLogout, user }) => {
    const [sidebar, setSidebar] = useState(false);

    console.log('Propriedades recebidas no Header:', user); // Log para depuração

    const toggleSidebar = () => setSidebar(!sidebar);

    // Define o título dinamicamente com base no papel do usuário e equipe
    const title = user
        ? `Painel da Equipe ${user.translationTeam || 'Global'} - Logado como ${user.username} (${user.role})`
        : 'Painel Usuário';

    console.log('Título do Header:', title); // Log para verificar o título

    return (
        <>
            {/* Cabeçalho Principal */}
            <Container>
                {/* Botão para abrir/fechar a sidebar */}
                <FaBars onClick={toggleSidebar} style={{ cursor: 'pointer', fontSize: '1.5em' }} />
                
                {/* Título dinâmico */}
                <h2 style={{ color: 'white', margin: '0 auto', textAlign: 'center' }}>{title}</h2>
                
                {/* Botão de logout */}
                <LogoutButton onClick={onLogout}>Sair</LogoutButton>
            </Container>

            {/* Sidebar controlada pelo estado */}
            {sidebar && (
                <Sidebar
                    setActive={setSidebar}
                    user={user} // Passando usuário para o menu de configurações
                />
            )}
        </>
    );
};

export default Header;
