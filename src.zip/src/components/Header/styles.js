import styled from 'styled-components';

export const Container = styled.div`
    height: 60px;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background-color: #1A202C;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;

    > svg {
        color: white;
        margin-left: 20px;
        cursor: pointer;
    }
`;

export const LogoutButton = styled.button`
    background-color: #e74c3c;
    color: white;
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-right: 20px;

    &:hover {
        background-color: #c0392b;
    }
`;
