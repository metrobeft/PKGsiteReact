import React, { createContext, useState, useEffect } from 'react';
import { findUserByUsername } from '../bdteste/BDteste'; // Importa função de busca de usuários

// Cria o contexto do usuário
export const UserContext = createContext();

// Provedor do contexto
export const UserProvider = ({ children }) => {
    const [user, setUser] = useState(null); // Inicializa o estado do usuário como null
    const [isLoggedIn, setIsLoggedIn] = useState(false); // Controla o estado de autenticação

    // Logs iniciais de estado
    useEffect(() => {
        console.log('[UserProvider] Estado inicial:', { user, isLoggedIn });
    }, []);

    // Função de login
    const login = (username, password) => {
        if (!username || !password) {
            console.warn('[UserProvider] Nome de usuário ou senha não fornecidos.');
            alert('Por favor, preencha todos os campos.');
            return;
        }

        console.log(`[UserProvider] Tentativa de login: ${username.trim()}`);
        const foundUser = findUserByUsername(username.trim()); // Busca o usuário no "banco de dados"

        if (foundUser) {
            if (foundUser.password === password.trim()) {
                console.log('[UserProvider] Login bem-sucedido:', foundUser);
                setUser(foundUser);
                setIsLoggedIn(true);
                alert(`Bem-vindo, ${foundUser.username}!`);
            } else {
                console.error('[UserProvider] Senha incorreta.');
                alert('Senha incorreta! Por favor, tente novamente.');
            }
        } else {
            console.error('[UserProvider] Usuário não encontrado.');
            alert('Usuário não encontrado! Verifique seu nome de usuário.');
        }
    };

    // Função de logout
    const logout = () => {
        console.log('[UserProvider] Logout iniciado.');
        setUser(null); // Reseta o estado do usuário
        setIsLoggedIn(false); // Define que o usuário não está mais autenticado
        alert('Você foi desconectado.');
    };

    // Persistência de login (opcional)
    useEffect(() => {
        const storedUser = JSON.parse(localStorage.getItem('user'));
        if (storedUser) {
            console.log('[UserProvider] Sessão restaurada:', storedUser);
            setUser(storedUser);
            setIsLoggedIn(true);
        }
    }, []);

    useEffect(() => {
        if (isLoggedIn && user) {
            localStorage.setItem('user', JSON.stringify(user));
        } else {
            localStorage.removeItem('user');
        }
    }, [isLoggedIn, user]);

    return (
        <UserContext.Provider value={{ user, isLoggedIn, login, logout }}>
            {children}
        </UserContext.Provider>
    );
};