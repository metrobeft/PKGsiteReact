import React from 'react';

const FileSelector = ({ onChange }) => (
    <div className="dashboard-section">
        <h2>Selecione o Arquivo</h2>
        <select onChange={(e) => onChange(e.target.value)}>
            <option value="">Escolha um arquivo</option>
            <option value="Arquivo 1">Arquivo 1</option>
            <option value="Arquivo 2">Arquivo 2</option>
        </select>
    </div>
);

export default FileSelector;
