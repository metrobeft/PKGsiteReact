import React from 'react';

const IASelector = ({ onChange }) => (
    <div className="dashboard-section">
        <h2>Selecione a IA de Tradução</h2>
        <select onChange={(e) => onChange(e.target.value)}>
            <option value="">Escolha uma IA</option>
            <option value="Gemini">Gemini</option>
            <option value="Azure">Azure</option>
            <option value="GPT">GPT</option>
            <option value="Copilot">Copilot</option>
        </select>
    </div>
);

export default IASelector;
