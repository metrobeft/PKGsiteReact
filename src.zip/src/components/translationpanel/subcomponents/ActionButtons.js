import React from 'react';

const ActionButtons = ({ onSavePartial, onSaveFinal }) => (
    <div className="button-group">
        <button className="save-partial" onClick={onSavePartial}>
            Salvar Parcialmente
        </button>
        <button className="save-final" onClick={onSaveFinal}>
            Salvar Definitivo
        </button>
    </div>
);

export default ActionButtons;
