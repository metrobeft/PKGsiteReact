import React from 'react';
import './TranslationBox.css';

const TranslationBox = ({ originalText, translatedText, onTranslatedChange }) => (
    <div className="dashboard-section">
        <h2>Tradução</h2>
        <div className="translation-box">
            <div className="text-area-wrapper">
                <label className="text-label">Input</label>
                <textarea
                    className="text-area input-text"
                    value={originalText}
                    readOnly
                />
            </div>
            <div className="text-area-wrapper">
                <label className="text-label">Output</label>
                <textarea
                    className="text-area output-text"
                    placeholder="Tradução gerada pela IA aparecerá aqui..."
                    value={translatedText}
                    onChange={(e) => onTranslatedChange(e.target.value)}
                />
            </div>
        </div>
    </div>
);

export default TranslationBox;
