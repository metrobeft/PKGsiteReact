import React from 'react';

const ProjectSelector = ({ projects, onChange }) => (
    <div className="dashboard-section">
        <h2>Selecione o Projeto</h2>
        <select onChange={(e) => onChange(e.target.value)}>
            <option value="">Escolha um projeto</option>
            {projects.map((project) => (
                <option key={project.id} value={project.name}>
                    {project.name}
                </option>
            ))}
        </select>
    </div>
);

export default ProjectSelector;
