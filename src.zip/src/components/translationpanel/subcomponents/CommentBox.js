import React from 'react';

const CommentBox = ({ fileComment, newComment, onNewCommentChange }) => (
    <div className="dashboard-section">
        <h2>Comentários</h2>
        <textarea className="comment-box" value={fileComment} readOnly />
        <textarea
            className="comment-box"
            placeholder="Adicione um comentário para este arquivo..."
            value={newComment}
            onChange={(e) => onNewCommentChange(e.target.value)}
        />
    </div>
);

export default CommentBox;
