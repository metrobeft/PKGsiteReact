import React, { useState } from 'react';
import Layout from '../layout/Layout';
import ProjectSelector from './subcomponents/ProjectSelector';
import FileSelector from './subcomponents/FileSelector';
import IASelector from './subcomponents/IASelector';
import TranslationBox from './subcomponents/TranslationBox';
import CommentBox from './subcomponents/CommentBox';
import ActionButtons from './subcomponents/ActionButtons';
import './TranslationPanel.css';

const TranslationPanel = ({ onLogout, projects }) => {
    const [selectedProject, setSelectedProject] = useState('');
    const [selectedFile, setSelectedFile] = useState('');
    const [selectedIA, setSelectedIA] = useState('');
    const [originalText, setOriginalText] = useState('Exemplo de texto original aqui...');
    const [translatedText, setTranslatedText] = useState('');
    const [fileComment, setFileComment] = useState('Comentário padrão do projeto.');
    const [newComment, setNewComment] = useState('');

    const handleSavePartial = () => {
        alert('Tradução salva parcialmente!');
    };

    const handleSaveFinal = () => {
        alert('Tradução salva definitivamente!');
    };

    return (
        <Layout title="Painel de Tradução" onLogout={onLogout}>
            <div className="dashboard-box">
                <ProjectSelector projects={projects} onChange={setSelectedProject} />
                {selectedProject && <FileSelector onChange={setSelectedFile} />}
                {selectedFile && <IASelector onChange={setSelectedIA} />}
                {selectedIA && (
                    <>
                        <TranslationBox
                            originalText={originalText}
                            translatedText={translatedText}
                            onTranslatedChange={setTranslatedText}
                        />
                        <CommentBox
                            fileComment={fileComment}
                            newComment={newComment}
                            onNewCommentChange={setNewComment}
                        />
                        <ActionButtons
                            onSavePartial={handleSavePartial}
                            onSaveFinal={handleSaveFinal}
                        />
                    </>
                )}
            </div>
        </Layout>
    );
};

export default TranslationPanel;
