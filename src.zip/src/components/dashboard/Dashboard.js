import React, { useEffect, useState, useMemo } from 'react';
import Layout from '../layout/Layout';
import './Dashboard.css';
import { sampleProjects, users } from '../bdteste/BDteste';

// Função para calcular a porcentagem de conclusão de um projeto
const getCompletionPercentage = (project) => {
    if (!project.totalFiles) return 0;
    const totalReviewed = project.reviewedFiles + project.partiallyReviewedFiles;
    return Math.round((totalReviewed / project.totalFiles) * 100);
};

// Função para filtrar projetos com base no papel do usuário
const filterProjectsForUser = (user) => {
    if (!user) {
        console.warn('[Dashboard] Usuário não definido!');
        return [];
    }

    if (user.role === 'admin') {
        return sampleProjects;
    }

    if (user.role === 'adminGrupo') {
        return sampleProjects.filter((project) => project.group === user.translationTeam);
    }

    if (user.role === 'userGrupo') {
        return sampleProjects.filter(
            (project) =>
                project.group === user.translationTeam || project.members.includes(user.id)
        );
    }

    return sampleProjects.filter((project) => project.members.includes(user.id));
};

// Função para filtrar membros com base no papel do usuário
const filterUsersForUser = (user) => {
    if (!user) {
        console.warn('[Dashboard] Usuário não definido!');
        return [];
    }

    if (user.role === 'admin') {
        return users;
    }

    if (user.role === 'adminGrupo') {
        return users.filter((member) => member.translationTeam === user.translationTeam);
    }

    if (user.role === 'userGrupo') {
        return users.filter((member) => member.translationTeam === user.translationTeam);
    }

    return users.filter((member) => member.id === user.id);
};

const Dashboard = ({ onLogout, user }) => {
    const [expandedUser, setExpandedUser] = useState(null);

    useEffect(() => {
        console.log('[Dashboard] Usuário recebido:', user);
        if (!user) {
            console.error('[Dashboard] Nenhum usuário autenticado encontrado!');
        }
    }, [user]);

    // Filtragem dos projetos e usuários
    const filteredProjects = useMemo(() => filterProjectsForUser(user), [user]);
    const filteredUsers = useMemo(() => filterUsersForUser(user), [user]);

    // Separação dos projetos por status
    const activeProjects = filteredProjects.filter((project) => project.status === 'em andamento');
    const finishedProjects = filteredProjects.filter((project) => project.status === 'finalizado');
    const droppedProjects = filteredProjects.filter((project) => project.status === 'dropado');

    // Alternar exibição de projetos de um usuário
    const toggleUserProjects = (userId) => {
        setExpandedUser((prev) => (prev === userId ? null : userId));
    };

    // Renderiza uma seção de projetos
    const renderProjectSection = (title, projects) => (
        <div className="project-section">
            <h3>{title}</h3>
            {projects.map((project) => {
                const percentage = getCompletionPercentage(project);
                const barColor =
                    percentage === 100
                        ? 'green'
                        : project.status === 'dropado'
                        ? 'red'
                        : percentage < 50
                        ? 'orange'
                        : '#4c6ef5';

                return (
                    <div key={project.id} className="project-progress">
                        <span className="project-title">
                            {project.name} - <strong>{project.status}</strong>
                        </span>
                        <div className="progress-bar">
                            <div
                                className="progress"
                                style={{
                                    width: `${percentage}%`,
                                    backgroundColor: barColor,
                                }}
                            >
                                {percentage}%
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
    );

    return (
        <Layout onLogout={onLogout} user={user}>
            <div className="dashboard-box">
                {/* Comunicados */}
                <div className="dashboard-section">
                    <h2>Comunicados</h2>
                    <p>Informações importantes sobre o andamento dos projetos serão exibidas aqui.</p>
                </div>

                {/* Projetos Agrupados */}
                <div className="dashboard-section">
                    <h2>Projetos:</h2>
                    {renderProjectSection('Projetos Ativos', activeProjects)}
                    {renderProjectSection('Projetos Finalizados', finishedProjects)}
                    {renderProjectSection('Projetos Dropados', droppedProjects)}
                </div>

                {/* Lista de Membros */}
                <div className="dashboard-section">
                    <h2>Lista de Membros</h2>
                    <ul className="dashboard-list">
                        {filteredUsers.map((currentUser) => (
                            <li key={currentUser.id}>
                                <div
                                    className={`user-name ${
                                        expandedUser === currentUser.id ? 'expanded' : ''
                                    }`}
                                    onClick={() => toggleUserProjects(currentUser.id)}
                                >
                                    {currentUser.username}
                                </div>
                                {expandedUser === currentUser.id && (
                                    <ul className="project-list">
                                        {filteredProjects
                                            .filter((project) =>
                                                project.members.includes(currentUser.id)
                                            )
                                            .map((project) => (
                                                <li key={project.id} className="project-item">
                                                    {project.name} - {getCompletionPercentage(project)}%
                                                </li>
                                            ))}
                                    </ul>
                                )}
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </Layout>
    );
};

export default Dashboard;
