// Dados de usuários
export const users = [
    // Admin Global
    {
        id: 1,
        username: 'adm',
        password: 'adm',
        email: 'adm@exemplo.com',
        contactInfo: '1234-5678',
        bankInfo: 'Banco XPTO, Conta: 1234-5',
        role: 'admin', // Admin Global
        translationTeam: null, // Não pertence a uma equipe específica
        assignedProjects: [], // Admin global não precisa de projetos atribuídos
    },

    // Admin do Grupo A
    {
        id: 2,
        username: 'adminGrupoA',
        password: 'adminGrupoA',
        email: 'adminGrupoA@exemplo.com',
        contactInfo: '9876-5432',
        bankInfo: 'Banco XPTO, Conta: 6789-0',
        role: 'adminGrupo', // Admin do Grupo A
        translationTeam: 'Equipe Alpha', // Nome do grupo
        assignedProjects: [1, 2, 3, 4], // Admin participa de todos os projetos de seu grupo
    },

    // Membros do Grupo A
    {
        id: 3,
        username: 'membro1A',
        password: 'membro1A',
        email: 'membro1A@exemplo.com',
        contactInfo: '1234-0000',
        bankInfo: 'Banco XPTO, Conta: 1111-1',
        role: 'userGrupo',
        translationTeam: 'Equipe Alpha',
        assignedProjects: [1, 2], // Projetos atribuídos
    },
    {
        id: 4,
        username: 'membro2A',
        password: 'membro2A',
        email: 'membro2A@exemplo.com',
        contactInfo: '5678-0000',
        bankInfo: 'Banco XPTO, Conta: 2222-2',
        role: 'userGrupo',
        translationTeam: 'Equipe Alpha',
        assignedProjects: [2, 3], // Projetos atribuídos
    },
    {
        id: 5,
        username: 'membro3A',
        password: 'membro3A',
        email: 'membro3A@exemplo.com',
        contactInfo: '9012-0000',
        bankInfo: 'Banco XPTO, Conta: 3333-3',
        role: 'userGrupo',
        translationTeam: 'Equipe Alpha',
        assignedProjects: [3, 4], // Projetos atribuídos
    },

    // Admin do Grupo B
    {
        id: 6,
        username: 'adminGrupoB',
        password: 'adminGrupoB',
        email: 'adminGrupoB@exemplo.com',
        contactInfo: '3456-7890',
        bankInfo: 'Banco XPTO, Conta: 4444-4',
        role: 'adminGrupo', // Admin do Grupo B
        translationTeam: 'Equipe Beta', // Nome do grupo
        assignedProjects: [5, 6, 7, 8, 9], // Admin participa de todos os projetos de seu grupo
    },

    // Membros do Grupo B
    {
        id: 7,
        username: 'membro1B',
        password: 'membro1B',
        email: 'membro1B@exemplo.com',
        contactInfo: '1357-0000',
        bankInfo: 'Banco XPTO, Conta: 5555-5',
        role: 'userGrupo',
        translationTeam: 'Equipe Beta',
        assignedProjects: [5, 6], // Projetos atribuídos
    },
    {
        id: 8,
        username: 'membro2B',
        password: 'membro2B',
        email: 'membro2B@exemplo.com',
        contactInfo: '2468-0000',
        bankInfo: 'Banco XPTO, Conta: 6666-6',
        role: 'userGrupo',
        translationTeam: 'Equipe Beta',
        assignedProjects: [6, 7], // Projetos atribuídos
    },
    {
        id: 9,
        username: 'membro3B',
        password: 'membro3B',
        email: 'membro3B@exemplo.com',
        contactInfo: '1111-2222',
        bankInfo: 'Banco XPTO, Conta: 7777-7',
        role: 'userGrupo',
        translationTeam: 'Equipe Beta',
        assignedProjects: [7, 8], // Projetos atribuídos
    },
    {
        id: 10,
        username: 'membro4B',
        password: 'membro4B',
        email: 'membro4B@exemplo.com',
        contactInfo: '3333-4444',
        bankInfo: 'Banco XPTO, Conta: 8888-8',
        role: 'userGrupo',
        translationTeam: 'Equipe Beta',
        assignedProjects: [8, 9], // Projetos atribuídos
    },

    // Usuário Free
    {
        id: 11,
        username: 'freeuser',
        password: 'freeuser',
        email: 'freeuser@exemplo.com',
        contactInfo: '5555-6666',
        bankInfo: 'Banco XPTO, Conta: 3333-9',
        role: 'freeuser', // Usuário livre
        translationTeam: null, // Não pertence a uma equipe
        assignedProjects: [], // Nenhum projeto atribuído
    },
];

// Dados de projetos
export const sampleProjects = [
    {
        id: 1,
        name: 'Projeto Alpha',
        totalFiles: 100,
        totalLines: 15000,
        unreviewedFiles: 10,
        reviewedFiles: 85,
        partiallyReviewedFiles: 5,
        members: [2, 3], // IDs dos usuários que participam do projeto
        status: 'em andamento',
        progress: 85,
        group: 'Equipe Alpha',
        createdBy: 1, // Criado pelo admin global
    },
    {
        id: 2,
        name: 'Projeto Beta',
        totalFiles: 120,
        totalLines: 20000,
        unreviewedFiles: 15,
        reviewedFiles: 95,
        partiallyReviewedFiles: 10,
        members: [2, 3, 4],
        status: 'em andamento',
        progress: 80,
        group: 'Equipe Alpha',
        createdBy: 2,
    },
    {
        id: 3,
        name: 'Projeto Gamma',
        totalFiles: 90,
        totalLines: 13000,
        unreviewedFiles: 5,
        reviewedFiles: 75,
        partiallyReviewedFiles: 10,
        members: [2, 4, 5],
        status: 'em andamento',
        progress: 75,
        group: 'Equipe Alpha',
        createdBy: 2,
    },
    {
        id: 4,
        name: 'Projeto Delta',
        totalFiles: 110,
        totalLines: 18000,
        unreviewedFiles: 20,
        reviewedFiles: 80,
        partiallyReviewedFiles: 10,
        members: [2, 5],
        status: 'em andamento',
        progress: 70,
        group: 'Equipe Alpha',
        createdBy: 2,
    },
    {
        id: 5,
        name: 'Projeto Epsilon',
        totalFiles: 100,
        totalLines: 16000,
        unreviewedFiles: 8,
        reviewedFiles: 90,
        partiallyReviewedFiles: 2,
        members: [6, 7],
        status: 'em andamento',
        progress: 85,
        group: 'Equipe Beta',
        createdBy: 6,
    },
    {
        id: 6,
        name: 'Projeto Zeta',
        totalFiles: 95,
        totalLines: 14000,
        unreviewedFiles: 10,
        reviewedFiles: 80,
        partiallyReviewedFiles: 5,
        members: [6, 7, 8],
        status: 'em andamento',
        progress: 80,
        group: 'Equipe Beta',
        createdBy: 6,
    },
    {
        id: 7,
        name: 'Projeto Eta',
        totalFiles: 80,
        totalLines: 12000,
        unreviewedFiles: 5,
        reviewedFiles: 70,
        partiallyReviewedFiles: 5,
        members: [6, 8],
        status: 'em andamento',
        progress: 75,
        group: 'Equipe Beta',
        createdBy: 6,
    },
    {
        id: 8,
        name: 'Projeto Theta',
        totalFiles: 110,
        totalLines: 17000,
        unreviewedFiles: 15,
        reviewedFiles: 85,
        partiallyReviewedFiles: 10,
        members: [6, 9],
        status: 'em andamento',
        progress: 80,
        group: 'Equipe Beta',
        createdBy: 6,
    },
    {
        id: 9,
        name: 'Projeto Iota',
        totalFiles: 120,
        totalLines: 20000,
        unreviewedFiles: 10,
        reviewedFiles: 100,
        partiallyReviewedFiles: 10,
        members: [6, 9, 10],
        status: 'em andamento',
        progress: 90,
        group: 'Equipe Beta',
        createdBy: 6,
    },
];


// Funções utilitárias para manipular os dados
export const findUserByUsername = (username) => {
    const user = users.find((user) => user.username === username);
    console.log('findUserByUsername - Procurando usuário:', username);
    console.log('findUserByUsername - Resultado:', user || 'Usuário não encontrado');
    return user || null; // Retorna null caso o usuário não seja encontrado
};

export const findProjectById = (projectId) => {
    return sampleProjects.find((project) => project.id === projectId) || null; // Retorna null caso o projeto não seja encontrado
};

export const listProjectsForUser = (userId) => {
    if (!userId) return []; // Verifica se o ID é válido
    return sampleProjects.filter((project) => project.members.includes(userId));
};


export const listUsersByTeam = (user) => {
    if (!user) return [];
    if (user.role === 'admin') {
        // Admin global vê todos os usuários
        return users;
    } else if (user.translationTeam) {
        // Apenas membros do mesmo translationTeam
        return users.filter((u) => u.translationTeam === user.translationTeam);
    }
    // Caso o usuário não pertença a nenhum grupo
    return [];
};


export const listProjectsByTeam = (teamName) => {
    if (!teamName) return [];
    return sampleProjects.filter((project) => project.group === teamName);
};


export const isGroupAdmin = (user, teamName) => {
    if (!user || !teamName) return false;
    return user.role === 'adminGrupo' && user.translationTeam === teamName;
};



export const listAdminsByTeam = (teamName) => {
    if (!teamName) return [];
    return users.filter(
        (user) => user.role === 'adminGrupo' && user.translationTeam === teamName
    );
};


export const getUserProjects = (user) => {
    if (!user) return [];
    if (user.role === 'admin') {
        // Admin global pode acessar todos os projetos
        return sampleProjects;
    }
    return sampleProjects.filter((project) => project.members.includes(user.id));
};
