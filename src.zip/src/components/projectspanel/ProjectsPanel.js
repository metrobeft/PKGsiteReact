import React, { useState, useEffect, useMemo } from 'react';
import Layout from '../layout/Layout';
import './ProjectsPanel.css';

// Filtra os projetos acessíveis com base no usuário logado
const filterProjectsForUser = (projects, user) => {
    if (!user) {
        console.warn('[ProjectsPanel] Usuário não definido!');
        return [];
    }

    if (user.role === 'admin') {
        console.log('[ProjectsPanel] Admin logado, acesso a todos os projetos.');
        return projects;
    }

    if (user.role === 'adminGrupo') {
        console.log(`[ProjectsPanel] Admin de grupo logado. Acesso aos projetos do grupo: ${user.translationTeam}`);
        return projects.filter((project) => project.group === user.translationTeam);
    }

    if (user.role === 'userGrupo') {
        console.log('[ProjectsPanel] Usuário de grupo logado. Acesso aos projetos atribuídos.');
        return projects.filter((project) => user.assignedProjects?.includes(project.id));
    }

    console.warn(`[ProjectsPanel] Papel desconhecido: ${user.role}`);
    return [];
};

const ProjectsPanel = ({ onLogout, projects, user }) => {
    const [columns, setColumns] = useState(5);

    useEffect(() => {
        const adjustColumns = () => {
            const width = window.innerWidth;
            const cardWidth = 350; // Largura fixa de cada card
            const margin = 20; // Margem entre os cards
            const totalWidth = width - 40; // Largura disponível para os cards (com margem)
            const maxColumns = Math.max(1, Math.floor(totalWidth / (cardWidth + margin))); // Pelo menos 1 coluna
            setColumns(maxColumns);
        };

        adjustColumns(); // Ajuste inicial das colunas
        window.addEventListener('resize', adjustColumns); // Atualiza a largura ao redimensionar

        return () => {
            window.removeEventListener('resize', adjustColumns); // Limpeza do evento quando o componente for desmontado
        };
    }, []);

    if (!user) {
        console.error('[ProjectsPanel] Usuário não definido no componente!');
        return (
            <Layout title="Painel de Projetos" onLogout={onLogout}>
                <p className="no-projects-message">Erro: Usuário não autenticado.</p>
            </Layout>
        );
    }

    // Determina os projetos acessíveis com base no usuário
    const accessibleProjects = useMemo(() => filterProjectsForUser(projects, user), [projects, user]);

    // Agrupa os projetos acessíveis por grupo
    const groupedProjects = useMemo(() => {
        return accessibleProjects.reduce((groups, project) => {
            const group = project.group || 'Sem Grupo';
            if (!groups[group]) {
                groups[group] = [];
            }
            groups[group].push(project);
            return groups;
        }, {});
    }, [accessibleProjects]);

    console.log('[ProjectsPanel] Projetos agrupados:', groupedProjects);

    return (
        <Layout title="Painel de Projetos" onLogout={onLogout} user={user}>
            <div className="projects-container">
                {Object.keys(groupedProjects).length > 0 ? (
                    Object.keys(groupedProjects).map((group) => (
                        <div key={group} className="group-section">
                            <h2>{group}</h2>
                            <div className="projects-box">
                                <div
                                    className="projects-grid"
                                    style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}
                                >
                                    {groupedProjects[group].map((project) => (
                                        <div
                                            key={project.id}
                                            className="project-card-container"
                                        >
                                            <div className="project-card">
                                                <h3>{project.name}</h3>
                                                <ul className="project-details">
                                                    <li>Total de Arquivos: {project.totalFiles}</li>
                                                    <li>Total de Linhas: {project.totalLines}</li>
                                                    <li>Arquivos Não Revisados: {project.unreviewedFiles}</li>
                                                    <li>Arquivos Revisados: {project.reviewedFiles}</li>
                                                    <li>Arquivos Parcialmente Revisados: {project.partiallyReviewedFiles}</li>
                                                </ul>
                                                <button className="translate-button">Ir para Tradução</button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ))
                ) : (
                    <p className="no-projects-message">Nenhum projeto acessível encontrado!</p>
                )}
            </div>
        </Layout>
    );
};

export default ProjectsPanel;
