import styled from 'styled-components';

export const ItemContainer = styled.div`
    display: flex;
    align-items: center;
    padding: 15px 20px;
    color: #ecf0f1; /* Texto claro */
    cursor: pointer;
    text-decoration: none; /* Remove underline */
    font-size: 1rem;
    transition: background-color 0.3s ease, color 0.3s ease;

    > svg {
        margin-right: 10px;
        color: #bdc3c7; /* Ícone em cinza claro */
        transition: color 0.3s ease;
    }

    &:hover {
        background-color: #34495e; /* Cor de fundo ao passar o mouse */
        color: #1abc9c; /* Cor do texto ao passar o mouse */
        
        > svg {
            color: #1abc9c; /* Cor do ícone ao passar o mouse */
        }
    }
`;
