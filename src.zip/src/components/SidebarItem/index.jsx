import React from 'react';
import { Link } from 'react-router-dom';
import { ItemContainer } from './styles';

const SidebarItem = ({ Icon, Text, link }) => {
    return (
        <ItemContainer>
            <Link to={link} style={{ textDecoration: 'none', color: 'inherit' }}>
                {Icon && <Icon size={24} />}
                <span>{Text}</span>
            </Link>
        </ItemContainer>
    );
};

export default SidebarItem;
