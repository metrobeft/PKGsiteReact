import React, { useState } from 'react';
import './LoginPage.css';
import { findUserByUsername } from '../bdteste/BDteste';

const LoginPage = ({ onLogin }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [isLoggingIn, setIsLoggingIn] = useState(false); // Estado para controlar o login em progresso

    // Função para validar os campos antes do login
    const validateInputs = () => {
        console.log('[LoginPage] Validando campos de entrada.');
        if (!username.trim() || !password.trim()) {
            setError('Todos os campos devem ser preenchidos!');
            console.warn('[LoginPage] Campos não preenchidos corretamente.');
            return false;
        }
        setError('');
        console.log('[LoginPage] Campos validados com sucesso.');
        return true;
    };

    // Função para lidar com o login
    const handleLogin = () => {
        console.log('[LoginPage] Tentativa de login iniciada.');

        if (!validateInputs()) {
            console.log('[LoginPage] Validação falhou. Abortando login.');
            return;
        }

        setIsLoggingIn(true); // Indica que o login está em progresso
        console.log('[LoginPage] Buscando usuário no "banco de dados".');
        
        const user = findUserByUsername(username.trim());
        
        if (user) {
            console.log(`[LoginPage] Usuário encontrado: ${JSON.stringify(user)}`);
            
            if (user.password === password.trim()) {
                console.log(`[LoginPage] Senha correta. Login bem-sucedido como: ${user.role}`);
                onLogin(user.username, user.password); // Passa as credenciais ao contexto
                setError('');
            } else {
                console.error('[LoginPage] Senha incorreta.');
                setError('Senha incorreta! Verifique novamente.');
            }
        } else {
            console.error('[LoginPage] Usuário não encontrado.');
            setError('Usuário não encontrado! Verifique seu nome de usuário.');
        }
        setIsLoggingIn(false); // Finaliza o estado de login em progresso
    };

    return (
        <div className="login-box">
            <h2>Login</h2>
            <input
                type="text"
                placeholder="Usuário"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={isLoggingIn} // Desativa o campo durante o login
                onKeyPress={(e) => {
                    if (e.key === 'Enter') handleLogin();
                }}
            />
            <input
                type="password"
                placeholder="Senha"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={isLoggingIn} // Desativa o campo durante o login
                onKeyPress={(e) => {
                    if (e.key === 'Enter') handleLogin();
                }}
            />
            <button onClick={handleLogin} disabled={isLoggingIn || !username || !password}>
                {isLoggingIn ? 'Entrando...' : 'Entrar'}
            </button>
            {error && <p className="error">{error}</p>}
        </div>
    );
};

export default LoginPage;
