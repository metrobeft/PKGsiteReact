import React, { useState, useEffect } from 'react';
import { listUsersByTeam } from '../../bdteste/BDteste'; // Importa a função para listar usuários por equipe

const CriacaoProjetos = ({ user, sampleProjects, setProjects }) => {
    const [projectName, setProjectName] = useState('');
    const [projectTool, setProjectTool] = useState('');
    const [projectInstructions, setProjectInstructions] = useState('');
    const [selectedMembers, setSelectedMembers] = useState([]);
    const [file, setFile] = useState(null);
    const [teamMembers, setTeamMembers] = useState([]);

    // Carrega os membros do translationTeam usando a função listUsersByTeam
    useEffect(() => {
        if (user) {
            const members = listUsersByTeam(user).filter((member) => member.id !== user.id); // Exclui o próprio admin
            setTeamMembers(members);
        }
    }, [user]);

    const handleCreateProject = (e) => {
        e.preventDefault();

        if (!projectName.trim() || !projectTool.trim()) {
            alert('O nome do projeto e a ferramenta são obrigatórios.');
            return;
        }

        const newProject = {
            id: sampleProjects.length + 1,
            name: projectName,
            totalFiles: 0,
            totalLines: 0,
            unreviewedFiles: 0,
            reviewedFiles: 0,
            partiallyReviewedFiles: 0,
            members: [
                ...selectedMembers,
                ...teamMembers.filter((member) => member.role === 'admin').map((admin) => admin.id), // Adiciona admins automaticamente
            ],
            status: 'em andamento',
            progress: 0,
            group: user.translationTeam || 'Global', // Grupo definido ou global
            createdBy: user.id,
            file: file ? file.name : null,
        };

        setProjects((prevProjects) => [...prevProjects, newProject]);

        alert('Projeto criado com sucesso!');
        setProjectName('');
        setProjectTool('');
        setProjectInstructions('');
        setSelectedMembers([]);
        setFile(null);
    };

    const handleFileUpload = (e) => {
        setFile(e.target.files[0]);
    };

    const handleMemberSelect = (e) => {
        const memberId = parseInt(e.target.value, 10);
        if (selectedMembers.includes(memberId)) {
            setSelectedMembers((prev) => prev.filter((id) => id !== memberId));
        } else {
            setSelectedMembers((prev) => [...prev, memberId]);
        }
    };

    return (
        <div className="dashboard-section">
            <h2>Criação de Projetos</h2>
            <form className="form" onSubmit={handleCreateProject}>
                <input
                    type="text"
                    placeholder="Nome do Projeto"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    required
                />
                <select value={projectTool} onChange={(e) => setProjectTool(e.target.value)} required>
                    <option value="">Selecione a Ferramenta</option>
                    <option value="Ferramenta A">Ferramenta A</option>
                    <option value="Ferramenta B">Ferramenta B</option>
                </select>
                <textarea
                    placeholder="Instruções ou Comentários"
                    value={projectInstructions}
                    onChange={(e) => setProjectInstructions(e.target.value)}
                ></textarea>
                <div className="member-list">
                    <h3>Selecione os Membros do Projeto</h3>
                    {teamMembers.length > 0 ? (
                        teamMembers.map((member) => (
                            <div key={member.id} className="member-item">
                                <label>
                                    <input
                                        type="checkbox"
                                        value={member.id}
                                        checked={selectedMembers.includes(member.id)}
                                        onChange={handleMemberSelect}
                                    />
                                    {` ${member.username}`}
                                </label>
                            </div>
                        ))
                    ) : (
                        <p>Carregando membros...</p>
                    )}
                </div>
                <div className="file-upload">
                    <h3>Upload de Arquivo TXT</h3>
                    <input type="file" accept=".txt" onChange={handleFileUpload} />
                    {file && <p>Arquivo selecionado: {file.name}</p>}
                </div>
                <button type="submit">Criar Projeto</button>
            </form>
        </div>
    );
};

export default CriacaoProjetos;
