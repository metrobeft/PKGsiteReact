import React from 'react';

const Ferramentas = () => {
    return (
        <div className="dashboard-section">
            <h2>Ferramentas</h2>
            <div className="tool-buttons">
                <button>Exportar Json para txt</button>
                <button>Exportar Py para txt</button>
                <button>Remover Duplicação</button>
                <button>Comparador</button>
            </div>
        </div>
    );
};

export default Ferramentas;
