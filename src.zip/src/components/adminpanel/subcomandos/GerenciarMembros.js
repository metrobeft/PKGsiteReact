import React, { useState } from 'react';
import { FaUserPlus, FaUserMinus } from 'react-icons/fa';
import { users } from '../../bdteste/BDteste'; // Importe a lista de usuários

const GerenciarMembros = ({ user, sampleProjects, setProjects }) => {
    const [selectedProjectId, setSelectedProjectId] = useState('');
    const [allocatedMembers, setAllocatedMembers] = useState([]);
    const [unallocatedMembers, setUnallocatedMembers] = useState([]);
    const [isModified, setIsModified] = useState(false); // Controla se houve alterações

    // Atualiza os membros do projeto selecionado
    const updateProjectMembers = (projectId) => {
        const project = sampleProjects.find((p) => p.id === parseInt(projectId, 10));
        if (project) {
            const membersInProject = project.members.map((memberId) =>
                users.find((u) => u.id === memberId)
            );

            const additionalGroupMembers = users.filter(
                (u) =>
                    u.translationTeam === project.group &&
                    !project.members.includes(u.id)
            );

            setAllocatedMembers(membersInProject);
            setUnallocatedMembers(additionalGroupMembers);
        } else {
            setAllocatedMembers([]);
            setUnallocatedMembers([]);
        }
    };

    const handleProjectSelect = (e) => {
        const projectId = e.target.value;
        setSelectedProjectId(projectId);
        updateProjectMembers(projectId);
        setIsModified(false); // Reseta o estado de modificação ao selecionar outro projeto
    };

    const handleManageMember = (action, memberId) => {
        const projectIndex = sampleProjects.findIndex(
            (p) => p.id === parseInt(selectedProjectId, 10)
        );

        if (projectIndex === -1) {
            alert('Projeto não encontrado.');
            return;
        }

        const updatedProjects = [...sampleProjects];
        const project = updatedProjects[projectIndex];

        if (action === 'add') {
            if (!project.members.includes(memberId)) {
                project.members.push(memberId);
                setIsModified(true); // Marca como modificado
                alert('Membro adicionado ao projeto!');
            }
        } else if (action === 'remove') {
            project.members = project.members.filter((id) => id !== memberId);
            setIsModified(true); // Marca como modificado
            alert('Membro removido do projeto!');
        }

        setProjects(updatedProjects); // Atualiza os projetos no estado pai
        updateProjectMembers(selectedProjectId);
    };

    const handleSaveChanges = () => {
        // Simula envio para o banco de dados ou atualizações definitivas
        alert('Alterações salvas com sucesso!');
        setIsModified(false); // Reseta o estado de modificação
    };

    return (
        <div className="dashboard-section">
            <h2>Gerenciar Membros em Projetos</h2>
            <select value={selectedProjectId} onChange={handleProjectSelect}>
                <option value="">Selecione um Projeto</option>
                {sampleProjects
                    .filter((p) => user.role === 'admin' || p.group === user.translationTeam)
                    .map((project) => (
                        <option key={project.id} value={project.id}>
                            {project.name}
                        </option>
                    ))}
            </select>

            {selectedProjectId && (
                <div className="member-management">
                    <h3>Membros Alocados</h3>
                    <div className="member-list">
                        {allocatedMembers.map((member) => (
                            <div key={member.id} className="member-item">
                                <span>{`[ID: ${member.id}] ${member.username}`}</span>
                                <FaUserMinus
                                    className="icon remove"
                                    onClick={() => handleManageMember('remove', member.id)}
                                />
                            </div>
                        ))}
                    </div>

                    <h3>Membros Não Alocados</h3>
                    <div className="member-list">
                        {unallocatedMembers.map((member) => (
                            <div key={member.id} className="member-item">
                                <span>{`[ID: ${member.id}] ${member.username}`}</span>
                                <FaUserPlus
                                    className="icon add"
                                    onClick={() => handleManageMember('add', member.id)}
                                />
                            </div>
                        ))}
                    </div>

                    {isModified && (
                        <button className="save-button" onClick={handleSaveChanges}>
                            Salvar Alterações
                        </button>
                    )}
                </div>
            )}
        </div>
    );
};

export default GerenciarMembros;
