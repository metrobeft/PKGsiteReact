import React, { useState, useEffect } from 'react';

const CriacaoUsuarios = ({ user, users, setUsers }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('userGrupo');
    const [groupName, setGroupName] = useState('');
    const [groups, setGroups] = useState([]);
    const [isNewGroup, setIsNewGroup] = useState(false);

    // Carregar grupos disponíveis ao carregar o componente
    useEffect(() => {
        const loadGroups = () => {
            const adminGroups = users
                .filter((u) => u.role === 'adminGrupo')
                .map((u) => u.translationTeam);

            if (user.role === 'adminGrupo') {
                // Para adminGrupo, limite aos grupos do translationTeam atual
                setGroups([user.translationTeam]);
                setGroupName(user.translationTeam); // Fixa o grupo para admins de grupo
            } else if (user.role === 'admin') {
                // Admin global vê todos os grupos disponíveis
                setGroups([...new Set(adminGroups)]);
            }
        };
        loadGroups();
    }, [users, user]);

    const handleCreateUser = (e) => {
        e.preventDefault();

        if (!username.trim()) {
            alert('O nome de usuário é obrigatório.');
            return;
        }
        if (!password.trim()) {
            alert('A senha é obrigatória.');
            return;
        }
        if (users.some((u) => u.username === username)) {
            alert('Este nome de usuário já está em uso. Escolha outro.');
            return;
        }

        let assignedGroup = '';

        if (role === 'adminGrupo' || role === 'userGrupo') {
            if (user.role === 'adminGrupo') {
                // Admin de Grupo só pode criar usuários/administradores no próprio translationTeam
                if (groupName !== user.translationTeam) {
                    alert('Você só pode criar usuários ou administradores no seu próprio grupo.');
                    return;
                }
                assignedGroup = user.translationTeam;
            } else if (user.role === 'admin') {
                // Admin Global pode criar novos grupos ou usar grupos existentes
                if (isNewGroup) {
                    if (!groupName.trim()) {
                        alert('O nome do novo grupo é obrigatório.');
                        return;
                    }
                    assignedGroup = groupName;
                } else if (!groups.includes(groupName)) {
                    alert('Selecione um grupo existente válido.');
                    return;
                }
            }
        }

        const newUser = {
            id: Math.max(0, ...users.map((u) => u.id)) + 1,
            username,
            password,
            email: `${username}@exemplo.com`,
            contactInfo: '0000-0000',
            bankInfo: 'Banco XPTO, Conta: 0000-0',
            role,
            translationTeam: assignedGroup,
            assignedProjects: [],
        };

        setUsers([...users, newUser]);
        alert(`Usuário "${username}" criado com sucesso!`);

        setUsername('');
        setPassword('');
        setRole('userGrupo');
        setGroupName('');
        setIsNewGroup(false);
    };

    return (
        <div className="dashboard-section">
            <h2>Criação de Usuários</h2>
            <form className="form" onSubmit={handleCreateUser}>
                <input
                    type="text"
                    placeholder="Nome de Usuário"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                />
                <input
                    type="password"
                    placeholder="Senha"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <select value={role} onChange={(e) => setRole(e.target.value)}>
                    <option value="userGrupo">Usuário de Grupo</option>
                    <option value="adminGrupo">Administrador de Grupo</option>
                </select>
                {role === 'adminGrupo' && user.role === 'admin' && (
                    <>
                        <div>
                            <label>
                                <input
                                    type="radio"
                                    value="new"
                                    checked={isNewGroup}
                                    onChange={() => setIsNewGroup(true)}
                                />
                                Criar Novo Grupo
                            </label>
                            <label>
                                <input
                                    type="radio"
                                    value="existing"
                                    checked={!isNewGroup}
                                    onChange={() => setIsNewGroup(false)}
                                />
                                Usar Grupo Existente
                            </label>
                        </div>
                        {isNewGroup ? (
                            <input
                                type="text"
                                placeholder="Nome do Novo Grupo"
                                value={groupName}
                                onChange={(e) => setGroupName(e.target.value)}
                                required
                            />
                        ) : (
                            <select
                                value={groupName}
                                onChange={(e) => setGroupName(e.target.value)}
                                required
                            >
                                <option value="">Selecione um Grupo</option>
                                {groups.map((group) => (
                                    <option key={group} value={group}>
                                        {group}
                                    </option>
                                ))}
                            </select>
                        )}
                    </>
                )}
                {role === 'userGrupo' && (
                    <select
                        value={groupName}
                        onChange={(e) => setGroupName(e.target.value)}
                        required
                    >
                        <option value="">Selecione um Grupo</option>
                        {groups.map((group) => (
                            <option key={group} value={group}>
                                {group}
                            </option>
                        ))}
                    </select>
                )}
                <button type="submit">Criar Usuário</button>
            </form>
        </div>
    );
};

export default CriacaoUsuarios;
