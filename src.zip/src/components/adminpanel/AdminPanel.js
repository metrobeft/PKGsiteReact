import React, { useState } from 'react';
import Layout from '../layout/Layout';
import { sampleProjects as initialProjects, users as initialUsers } from '../bdteste/BDteste'; // Inclua os usuários
import './AdminPanel.css';
import CriacaoProjetos from './subcomandos/CriacaoProjetos';
import Ferramentas from './subcomandos/Ferramentas';
import GerenciarMembros from './subcomandos/GerenciarMembros';
import CriacaoUsuarios from './subcomandos/CriacaoUsuarios';

const AdminPanel = ({ onLogout, user }) => {
    const [projects, setProjects] = useState(initialProjects); // Estado local para projetos
    const [users, setUsers] = useState(initialUsers); // Estado local para usuários

    return (
        <Layout title="Painel de ADM" onLogout={onLogout} user={user}>
            <div className="dashboard-box">
                <CriacaoProjetos
                    user={user}
                    sampleProjects={projects}
                    setProjects={setProjects} // Passando o estado de projetos para CriacaoProjetos
                />
                <Ferramentas />
                <GerenciarMembros
                    user={user}
                    sampleProjects={projects}
                    setProjects={setProjects} // Passando a função para GerenciarMembros
                />
                <CriacaoUsuarios user={user} users={users} setUsers={setUsers} /> {/* Passando usuários */}
            </div>
        </Layout>
    );
};

export default AdminPanel;
