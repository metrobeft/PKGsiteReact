import React from 'react';
import ReactDOM from 'react-dom/client'; // Certifique-se de importar do pacote correto
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { UserProvider } from './components/context/UserContext'; // Importa o contexto

// Localiza o elemento root no DOM
const rootElement = document.getElementById('root');

// Cria o root e renderiza o App
if (rootElement) {
    const root = ReactDOM.createRoot(rootElement);
    root.render(
        <BrowserRouter>
            <UserProvider>
                <App />
            </UserProvider>
        </BrowserRouter>
    );
} else {
    console.error('Elemento root não encontrado no DOM.');
}
