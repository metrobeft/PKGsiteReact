import React, { useContext } from 'react';
import './css/global.css';
import { Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './components/loginpage/LoginPage';
import Dashboard from './components/dashboard/Dashboard';
import AccountSettings from './components/accountsettings/AccountSettings';
import AdminPanel from './components/adminpanel/AdminPanel';
import ProjectsPanel from './components/projectspanel/ProjectsPanel';
import TranslationPanel from './components/translationpanel/TranslationPanel';
import Header from './components/Header';
import { sampleProjects } from './components/bdteste/BDteste';
import { UserContext } from './components/context/UserContext';

// Componente para proteger rotas que requerem autenticação
const ProtectedRoute = ({ children, roleRequired }) => {
    const { isLoggedIn, user } = useContext(UserContext);

    console.log('[ProtectedRoute] Estado Atual:', { isLoggedIn, user, roleRequired });

    if (!isLoggedIn) {
        console.warn('[ProtectedRoute] Tentativa de acessar rota protegida sem autenticação.');
        return <Navigate to="/" replace />;
    }

    if (roleRequired && ![roleRequired].includes(user?.role)) {
        console.warn(
            `[ProtectedRoute] Acesso negado. Papel necessário: ${roleRequired}, papel do usuário: ${user?.role}`
        );
        return (
            <div style={{ padding: '20px', textAlign: 'center', color: 'red' }}>
                <h2>Acesso Negado</h2>
                <p>Você não tem permissão para acessar esta página.</p>
            </div>
        );
    }

    return children;
};

const App = () => {
    const { isLoggedIn, user, login, logout } = useContext(UserContext);

    console.log('[App] Estado Atual:', { isLoggedIn, user });

    // Define o título do painel com base no papel do usuário
    const title = user
        ? user.role === 'admin'
            ? `Painel ${user.translationTeam || 'Administrador'}`
            : user.role === 'adminGrupo'
            ? `Painel Equipe ${user.translationTeam || 'Grupo'}`
            : `Painel ${user.translationTeam || 'Usuário'}`
        : 'Painel';

    return (
        <div>
            {/* Renderiza o Header apenas se o usuário estiver autenticado */}
            {isLoggedIn && <Header onLogout={logout} title={title} user={user} />}

            <Routes>
                <Route
                    path="/"
                    element={!isLoggedIn ? <LoginPage onLogin={login} /> : <Navigate to="/dashboard" replace />}
                />
                <Route
                    path="/dashboard"
                    element={
                        <ProtectedRoute>
                            <Dashboard onLogout={logout} user={user} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/admin-panel"
                    element={
                        <ProtectedRoute roleRequired="admin">
                            <AdminPanel onLogout={logout} user={user} projects={sampleProjects} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/projects-panel"
                    element={
                        <ProtectedRoute>
                            <ProjectsPanel onLogout={logout} projects={sampleProjects} user={user} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/translation-panel"
                    element={
                        <ProtectedRoute>
                            <TranslationPanel onLogout={logout} projects={sampleProjects} user={user} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/account-settings"
                    element={
                        <ProtectedRoute>
                            <AccountSettings onLogout={logout} user={user} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="*"
                    element={
                        <div style={{ padding: '20px', textAlign: 'center' }}>
                            <h2>Página Não Encontrada</h2>
                            <p>A página que você está tentando acessar não existe.</p>
                            <button
                                onClick={() => (window.location.href = isLoggedIn ? '/dashboard' : '/')}
                                style={{
                                    padding: '10px 20px',
                                    marginTop: '10px',
                                    backgroundColor: '#007bff',
                                    color: '#fff',
                                    border: 'none',
                                    borderRadius: '5px',
                                    cursor: 'pointer',
                                }}
                            >
                                Voltar
                            </button>
                        </div>
                    }
                />
            </Routes>
        </div>
    );
};

export default App;
